
package Interfaces;

public interface Leible {
    void leer();
}
