
package Clases;

public enum Genero {
    FICCION,
    NO_FICCION,
    HISTORIA,
    CIENCIA;
}
